import sys

try:
    import pandas as pd
    import numpy as np

   
    wallets = pd.read_csv('Wallet.csv')['wallet_id'].dropna().unique()

    #  Generate Synthetic Wallet Data 
    def fetch_wallet_data(wallet):
        rng = np.random.default_rng(abs(hash(wallet)) % (2**32))
        data = {
            'total_borrowed': rng.uniform(1, 1000),
            'num_liquidations': rng.integers(0, 4),
            'largest_borrow': rng.uniform(1, 700),
            'repayment_ratio': rng.uniform(0.2, 1.0),
            'collateralization_ratio': rng.uniform(1.0, 2.2),
            'active_assets': rng.integers(1, 5),
            'protocol_age': rng.integers(30, 1000),
        }
        return data

    wallet_feature_list = []
    for w in wallets:
        d = fetch_wallet_data(w)
        d['wallet_id'] = w
        wallet_feature_list.append(d)
    df = pd.DataFrame(wallet_feature_list)

    #Feature Normalization 
    direct = ['total_borrowed', 'num_liquidations', 'largest_borrow']
    inverse = ['repayment_ratio', 'collateralization_ratio', 'active_assets', 'protocol_age']
    normed = {}

    for col in direct:
        normed[col] = (df[col] - df[col].min()) / (df[col].max() - df[col].min())

    for col in inverse:
        n = (df[col] - df[col].min()) / (df[col].max() - df[col].min())
        normed[col] = 1 - n

    normed_df = pd.DataFrame(normed)

    # Scoring 
    weights = {
        'total_borrowed':        0.25,
        'num_liquidations':      0.25,
        'largest_borrow':        0.10,
        'repayment_ratio':       0.10,
        'collateralization_ratio':0.15,
        'active_assets':         0.10,
        'protocol_age':          0.05
    }
    df['score'] = (normed_df * pd.Series(weights)).sum(axis=1)
    df['score'] = (df['score'] * 1000).round().astype(int)

   
    final_df = df[['wallet_id', 'score']]
    final_df.to_csv('wallet_scores.csv', index=False)

    print("Scoring complete! Output file: wallet_scores.csv")
except Exception as e:
    print("ERROR:", e, file=sys.stderr)
